const { DataTypes } = require('sequelize')
const sequelize = require('../conection/conection')
const Categorias = require('./categorias')
const Genero = require('./genero');

const Catalogo = sequelize.define('catalogo', {
    id_catalogo: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false,
    },
    poster: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    titulo: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    
    resumen: {
        type: DataTypes.TEXT,
        allowNull: false,
    },
    temporadas: {
        type: DataTypes.INTEGER,
        defaultValue: null,
    },
    trailer: {
        type: DataTypes.STRING,
        defaultValue: null,
    }
    }, {
        tableName: 'catalogo',
        timestamps: false,
    })


module.exports = Catalogo


