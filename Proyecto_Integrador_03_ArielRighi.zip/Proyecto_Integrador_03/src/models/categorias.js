const { DataTypes } = require('sequelize')
const sequelize = require('../conection/conection')

const Categorias = sequelize.define('categorias', {
    id_categorias: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false,
    },
    nombre: {
        type: DataTypes.STRING,
        allowNull: false, 
    }
}, {
    tableName: 'categorias',
    timestamps: false,
})

module.exports = Categorias