const { DataTypes } = require('sequelize');
const sequelize = require('../conection/conection');

const VistaCompleta = sequelize.define('VistaCompleta', {
    id_catalogo: {
        type: DataTypes.INTEGER,
        primaryKey: true
    },
    poster: {
        type: DataTypes.STRING
    },
    titulo: {
        type: DataTypes.STRING
    },
    categoria: {
        type: DataTypes.STRING,
    },
    resumen: {
        type: DataTypes.TEXT
    },
    temporadas: {
        type: DataTypes.INTEGER
    },
    trailer: {
        type: DataTypes.STRING
    },
    genero: {
        type: DataTypes.STRING
    },
    actor: {
        type: DataTypes.STRING
    }
}, {
    tableName: 'vistaCompleta',
    timestamps: false,
});

module.exports = VistaCompleta;