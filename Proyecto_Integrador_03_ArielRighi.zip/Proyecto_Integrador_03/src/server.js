const dotenv = require('dotenv');
dotenv.config();
const express = require('express');
const sequelize = require('./conection/conection')
const { Op } = require('sequelize');
const { QueryTypes } = require('sequelize');
const Catalogo = require('./models/catalogo')
const Categorias = require('./models/categorias')
const Genero = require('./models/genero')
const VistaCompleta = require('./models/vistaCompleta')

const server = express();
server.use(express.json());

//Consulta las categorias
server.get('/categorias', async (req, res) => {
    try {
        const categorias = await Categorias.findAll();
        res.status(200).send(categorias);
    } catch (error) {
        console.error('Error al consultar la base de datos:', error);
        res.status(500).send('Error al obtener las categorias desde la base de datos.');
    }
});

server.get('/catalogo', async (req, res) => {
    try {
        const catalogoCompleto = await VistaCompleta.findAll({
            raw: true,
            group: ['id_catalogo', 'actor', 'genero'], // Agrupar para evitar duplicados
        });
        res.status(200).send(catalogoCompleto);
    } catch (error) {
        console.error('Error al consultar la vista:', error);
        res.status(500).send('Error al obtener el catálogo desde la vista.');
    }
});

//Consulta la lista de generos
server.get('/genero', async (req, res) => {
    try {
   const genero = await Genero.findAll();
   res.status(200).send(genero);
   } catch (error) {
       console.error('Error al consultar la base de datos:', error);
       res.status(500).send('Error al obtener el genero desde la base de datos.');
   }
});

// Consultar el catálogo por número de ID
server.get('/catalogo/:id', async (req, res) => {
    const id_catalogo = Number(req.params.id);

    try {
        const catalogo = await Catalogo.findByPk(id_catalogo);

        if (!catalogo) {
            res.status(404).send('No se encontró ninguna película o serie con el ID proporcionado.');
        } else {
            res.status(200).send(catalogo);
        }
    } catch (error) {
        console.error('Error al consultar la base de datos:', error);
        res.status(500).send('Error al obtener el ID desde la base de datos.');
    }
});

//Consultar el catalogo por nombre del titulo
server.get('/catalogo/nombre/:nombre', async (req, res) => {
    try {
        const nombre = req.params.nombre;

        const catalogo = await Catalogo.findAll({
            where: {
                titulo: {
                    [Op.like]: `%${nombre}%`
                }
            }
        });

        if (catalogo.length === 0) {
            res.status(404).send('No se encontraron películas o series para el nombre proporcionado.');
        } else {
            res.status(200).send(catalogo);
        }
    } catch (error) {
        console.error('Error al consultar la base de datos:', error);
        res.status(500).send('Error al obtener el nombre desde la base de datos.');
    }
});

//Consultar el catalogo por el genero del titulo
server.get('/catalogo/genero/:genero', async (req, res) => {
    try {
        const genero = req.params.genero;

        const catalogo = await sequelize.query(
            'SELECT * FROM vista_genero WHERE genero_nombre LIKE :genero',
            {
                replacements: { genero: `%${genero}%` },
                type: sequelize.QueryTypes.SELECT,
            }
        );

        if (catalogo.length === 0) {
            res.status(404).send('No se encontraron películas o series para el género proporcionado.');
        } else {
            res.status(200).send(catalogo);
        }
    } catch (error) {
        console.error('Error al consultar la base de datos:', error);
        res.status(500).send('Error al obtener el género desde la base de datos.');
    }
});

//Consultar el catalogo por la categoria serie o pelicula
server.get('/catalogo/categoria/:categoria', async (req, res) => {
    try {
        const categoria = req.params.categoria;

        const catalogo = await sequelize.query(
            `SELECT * FROM catalogo WHERE categoria = :categoria`,
            {
                replacements: { categoria },
                type: sequelize.QueryTypes.SELECT,
            }
        );

        if (catalogo.length === 0) {
            // Si no se encontraron registros para la categoría
            res.status(404).send('No se encontraron películas o series para la categoría proporcionada.');
        } else {
            res.status(200).send(catalogo);
        }
    } catch (error) {
        console.error('Error al consultar la base de datos:', error);
        res.status(500).send('Error al obtener la categoría desde la base de datos.');
    }
});

//Control de rutas inexistentes
server.use('*', (req, res) => {
    res.status(404).send({error: 'La URL indicada, no existe en este servidor'})
});

// Método oyente de solicitudes
sequelize
    .authenticate()
    .then(() => {
        sequelize.sync({ force: false }).then(() => {
            server.listen(process.env.PORT, process.env.HOST, () => {
                console.log(`El servidor está escuchando en: http://${process.env.HOST}:${process.env.PORT}`);
            });
        }).catch(() => {
            console.log("Hubo un problema con la sincronización de la base de datos");
        })
    })
    .catch(() => {
        console.log("Hubo un problema con la autenticación de la base de datos");
    });

